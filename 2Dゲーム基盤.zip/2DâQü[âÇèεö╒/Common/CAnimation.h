//--------------------------------------------------------------------------------------
// File: CAnimation.cpp
//
// Copyright (c) S.G.Kohata. All rights reserved.
//--------------------------------------------------------------------------------------
#pragma once
#include "DXUT.h"
#include "DXUTcamera.h"
#include "DXUTsettingsdlg.h"
#include "SDKmisc.h"
#include "CAllocateHierarchy.h"
#include "CResource.h"

class CAnimation : public CResource {

	struct animation_t {
		int							nCount;			// �Q�ƃJ�E���g
		WCHAR*						pFilename;		// �t�@�C����
		LPD3DXFRAME					_pFrameRoot;
		ID3DXAnimationController*	_pAnimController;
		CAllocateHierarchy			_alloc;
	};

	animation_t*			m_pAnimation;		// �e���
	UINT					m_nAnimationTrack;
	UINT					m_nAnimationTrackOld;
	float					m_fTime;
	float					m_fTimeOld;
	float					m_fSpeed;
	float					m_fChangeTimeBase;
	float					m_fChangeTime;
	float					m_fStopTime;
	float					m_fStopTimeOld;
	float					m_fRadius;
	D3DXVECTOR3				m_sCenter;
	int						m_nVertices;

	void					Create(LPDIRECT3DDEVICE9 pd3dDevice, const WCHAR* pFilename);
	void					Destroy();
	void					DrawMeshContainer(IDirect3DDevice9 *pd3dDevice, LPD3DXMESHCONTAINER pMeshContainerBase, LPD3DXFRAME pFrameBase);
	HRESULT					SetupBoneMatrixPointersOnMesh(LPD3DXMESHCONTAINER pMeshContainer);
	HRESULT					SetupBoneMatrixPointers(LPD3DXFRAME pFrame);
	void					UpdateSkinningMethod(LPD3DXFRAME pFrameBase);
	void					ReleaseAttributeTable(LPD3DXFRAME pFrameBase);
	void					ComputeBoundingSphere(LPD3DXFRAME pFrameBase);
	void					CopyMaterialDiffuseToAmbient(D3DMATERIAL9* pMaterial);
	void					UpdateFrameMatrices(LPD3DXMATRIX pParentMatrix, LPD3DXFRAME pFrameBase = NULL);

public:
							CAnimation(IDirect3DDevice9* pd3dDevice, const WCHAR* pFilename);
	virtual					~CAnimation();
	UINT					GetTracks();
	void					SetSpeed(float speed);
	void					SetTime(float fElapsedTime);
	FLOAT					GetRadius();
	D3DXVECTOR3*			GetCenter();
	void					ResetTime();
	void					ChangeAnimation(UINT track, float time, float endTime = -1);
	void					Render(IDirect3DDevice9 *pd3dDevice, LPD3DXFRAME pFrame = NULL);
	D3DXMATRIX*				GetMatrix(char *pName, D3DXFRAME_DERIVED *pParent = NULL, D3DXMATRIX *pMat = NULL);
};

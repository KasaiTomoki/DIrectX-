#include "AABB.h"

AABB::AABB(void)
{
	// �ꉞ�N���A���Ă���
	SetCenterWH(0, 0, 0, 0);
}

// �ŏ��|�ő�̏�񂩂璆�S�|���̏����쐬����
void AABB::SetMinMax(FLOAT minX, FLOAT minY, FLOAT maxX, FLOAT maxY)
{
	center = D3DXVECTOR2((maxX+minX)/2,   (maxY+minY)/2);
	wh     = D3DXVECTOR2((maxX-minX+1)/2, (maxY-minY+1)/2);
	CalculateMinMax();
}

// �ŏ��|�ő�̏�񂩂璆�S�|���̏����쐬����
void AABB::SetCenterWH(FLOAT centerX, FLOAT centerY, FLOAT widthby2, FLOAT heightby2)
{
	center = D3DXVECTOR2(centerX,  centerY);
	wh     = D3DXVECTOR2(widthby2, heightby2);
	CalculateMinMax();
}

void AABB::SetCenter(FLOAT centerx, FLOAT centery)
{
	center = D3DXVECTOR2(centerx,  centery);
	CalculateMinMax();
}

void AABB::SetMinMax(D3DXVECTOR2* pMin, D3DXVECTOR2* pMax)
{
	SetMinMax(pMin->x, pMin->y, pMax->x, pMax->y);
}

void AABB::SetCenterWH(D3DXVECTOR2* pCenter, D3DXVECTOR2* pWHby2)
{
	SetCenterWH(pCenter->x, pCenter->y, pWHby2->x, pWHby2->y);
}

void AABB::SetCenter(D3DXVECTOR2* pCenter)
{
	SetCenter(pCenter->x, pCenter->y);
}

void AABB::SetCenterX(FLOAT centerX)
{
	SetCenter(centerX, center.y);
}

void AABB::SetCenterY(FLOAT centerY)
{
	SetCenter(center.x, centerY);
}

void AABB::AddCenter(FLOAT centerX, FLOAT centerY)
{
	SetCenter(center.x + centerX, center.y + centerY);
}

void AABB::AddCenter(D3DXVECTOR2* pCenter)
{
	SetCenter(center.x + pCenter->x, center.y + pCenter->y);
}

D3DXVECTOR2* AABB::GetCenter()
{
	return &center;
}

FLOAT AABB::GetWidthby2()
{
	return wh.x;
}

FLOAT AABB::GetHeightby2()
{
	return wh.y;
}

// AABB����p�ɐ��l�̌v�Z���s��
void AABB::CalculateMinMax()
{
	min[0] = center.x - wh.x;
	max[0] = center.x + wh.x;
	min[1] = center.y - wh.y;
	max[1] = center.y + wh.y;
}

// ���������_��==�m�F
BOOL AABB::IsEqualFloating(FLOAT v1, FLOAT v2)
{
	#define EPSILON 0.00001f

	if (v1 != 0) {
		if (fabs(v1-v2)/v1 < EPSILON)
			return TRUE;
		else
			return FALSE;
	}
	else if (v2 != 0) {
		if (fabs(v1-v2)/v2 < EPSILON)
			return TRUE;
		else
			return FALSE;
	}
	else
		return TRUE;
}

// AABB���m���߂肱��ł��Ȃ����m�F
BOOL AABB::TestAABBAABB(AABB* pB)
{
	for (int i=0; i<2; i++) {
		if (max[i]     <= pB->min[i] ||
			pB->max[i] <= min[i])
			return FALSE;
	}
	return TRUE;
}

// ����̏Փ˖ʂւƕϊ�����
Collision_e AABB::InverseType(Collision_e cType)
{
	switch (cType) {
		case COLLISION_LEFT:		return COLLISION_RIGHT;
		case COLLISION_RIGHT:		return COLLISION_LEFT;
		case COLLISION_UP:			return COLLISION_DOWN;
		case COLLISION_DOWN:		return COLLISION_UP;
		case COLLISION_LEFT_UP:		return COLLISION_RIGHT_DOWN;
		case COLLISION_LEFT_DOWN:	return COLLISION_RIGHT_UP;
		case COLLISION_RIGHT_UP:	return COLLISION_LEFT_DOWN;
		case COLLISION_RIGHT_DOWN:	return COLLISION_LEFT_UP;
	}
	return COLLISION_NULL;
}

// pA    :�ړ����̂`
// pB    :�ړ����̂a
// pVa   :�ړ����̂`�̉^���x�N�g��
// pVb   :�ړ����̂a�̉^���x�N�g��
// pFirst:�Ԃ���܂ł̎��ԁi���j
// pType1:���̂a�̂Ԃ�������
// pType2:���̂a�̂Ԃ�������
BOOL AABB::IntersectAABBAABB(AABB* pB, D3DXVECTOR2* pVa, D3DXVECTOR2* pVb, FLOAT* pFirst, Collision_e* pType1, Collision_e* pType2)
{
	FLOAT       v[2]   = {pVb->x - pVa->x, pVb->y - pVa->y};
	FLOAT       tFirst = 0,
		        tLast  = 1;
	Collision_e cType2 = COLLISION_NULL;

	if (v[0] == 0 && v[1] == 0)
		return FALSE;

	// �߂肱��ł��Ȃ����m�F
	if (TestAABBAABB(pB)) {
		if (fabs(min[0] - pB->max[0])<8)
			(int&)cType2 |= COLLISION_RIGHT;
		if (fabs(pB->min[0] - max[0])<8)
			(int&)cType2 |= COLLISION_LEFT;
		if (fabs(min[1] - pB->max[1])<8)
			(int&)cType2 |= COLLISION_DOWN;
		if (fabs(pB->min[1] - max[1])<8)
			(int&)cType2 |= COLLISION_UP;
		*pFirst = tFirst;
		*pType1 = InverseType(cType2);
		*pType2 = cType2;
		return TRUE;
	}

	for (int i=0; i<2; i++) {
		FLOAT time;
		if (v[i] == 0) {
			if (max[i] <= pB->min[i] ||
				pB->max[i] <= min[i])
				return FALSE;
		}
		if (v[i] < 0) {
			if (pB->max[i] <= min[i])
				return FALSE;
			if (max[i] <= pB->min[i]) {
				time = (max[i] - pB->min[i]) / v[i];
				if (IsEqualFloating(tFirst, time)) {
					tFirst = time;
					if (i == 0)
						(int&)cType2 |= COLLISION_LEFT;
					else
						(int&)cType2 |= COLLISION_UP;
				}
				else if (tFirst < time) {
					tFirst = time;
					if (i == 0)
						cType2 = COLLISION_LEFT;
					else
						cType2 = COLLISION_UP;
				}
			}
			if (pB->max[i] > min[i]) {
				time = (min[i] - pB->max[i]) / v[i];
				if (tLast > time) {
					tLast = time;
				}
			}
		}
		if (v[i] > 0) {
			if (pB->min[i] >= max[i])
				return FALSE;
			if (pB->max[i] <= min[i]) {
				time = (min[i] - pB->max[i]) / v[i];
				if (IsEqualFloating(tFirst, time)) {
					tFirst = time;
					if (i == 0)
						(int&)cType2 |= COLLISION_RIGHT;
					else
						(int&)cType2 |= COLLISION_DOWN;
				}
				else if (tFirst < time) {
					tFirst = time;
					if (i == 0)
						cType2 = COLLISION_RIGHT;
					else
						cType2 = COLLISION_DOWN;
				}
			}
			if (max[i] > pB->min[i]) {
				time = (max[i] - pB->min[i]) / v[i];
				if (tLast > time) {
					tLast = time;
				}
			}
		}
		if (tFirst > tLast)
			return FALSE;
	}

	*pFirst = tFirst;
	*pType1 = InverseType(cType2);
	*pType2 = cType2;
	return TRUE;
}

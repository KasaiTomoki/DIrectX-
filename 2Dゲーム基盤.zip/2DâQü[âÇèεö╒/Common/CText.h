//-----------------------------------------------------------------------------
// File: Text.h
//
// Desc: ������̕\��
//-----------------------------------------------------------------------------
#pragma once
#include "DXUT.h"
#include "CSprite.h"

class CText {
	static LPDIRECT3DDEVICE9	pd3dDevice;
	static CSprite*				pText;

public:
	static void					Create(LPDIRECT3DDEVICE9 pd3dDevice);
	static void					Release();
	static void					Render(int color, int x, int y, float scaleX, float scaleY, char* fmt, ...);
};

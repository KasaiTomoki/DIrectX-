#include "ObjMng.h"

ObjMng::ObjMng()
{
	pObjList.clear();
}

ObjMng::~ObjMng()
{
	Clear();
}

void ObjMng::FrameMove()
{
	for (auto &pObj : pObjList) {
		pObj->FrameMove();
	}
}

void ObjMng::FrameRender()
{
	Object* pCheck = Object::GetpTop();
	vector<Object*> layerList;

	while (pCheck)
	{
		layerList.push_back(pCheck);
		pCheck = pCheck->GetpNext();
		continue;
	}

	for (int i = 0; i < layerList.size(); i++) {
		int nLayer = layerList[i]->GetLayer();
		for (int j = i + 1; j < layerList.size(); j++) {
			if (nLayer < layerList[j]->GetLayer()) {
				//���C���[���r���ă����_�����O��������ւ�
				Object* pSave = layerList[j];
				layerList[j] = layerList[i];
				layerList[i] = pSave;
				nLayer = layerList[j]->GetLayer();
			}
		}
	}

	for (auto &pObj : layerList) {
		pObj->FrameRender();
	}
}

void ObjMng::Clear()
{
	if (!pObjList.empty()) {
		for (auto &pObj : pObjList) {
			delete pObj;
		}

		pObjList.clear();//���X�g�����
	}
}

void ObjMng::SetPos()
{
	
}

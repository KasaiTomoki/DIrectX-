#include "Game.h"

Game::Game()
{
	SceneMng::Init(Scene_Title);
	Object::Initialize();
	pObjMng = new ObjMng();
}

Game::~Game()
{
	SceneMng::Destroy();
	Object::UnInitialize();
	delete pObjMng;
}

void Game::FrameMove()
{
	pObjMng->FrameMove();
}

void Game::FrameRender()
{
	pObjMng->FrameRender();

	//�V�[���ڍs�͍Ō�ɍs��
	SceneMng::Single()->LoadNextScene();
}
#include "Mathf.h"

Mathf::Mathf()
{
}

Mathf::~Mathf()
{
}

D3DXVECTOR2 Mathf::AngleToVec(float angle)
{
	float rad = D3DXToRadian(angle);
	return D3DXVECTOR2(cos(rad), sin(rad));
}

float Mathf::VecToAngle(D3DXVECTOR2 vec)
{
	return D3DXToDegree(atan2(vec.y, vec.x));
}

float Mathf::NormalRate(float num, float deno)
{
	float rate = num / deno;

	if (rate < 0)
		rate = 0;

	else if (rate > 1)
		rate = 1;

	return rate;
}

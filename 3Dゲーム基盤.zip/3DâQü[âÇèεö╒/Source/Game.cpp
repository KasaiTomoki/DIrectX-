#include "Game.h"

Game::Game()
{
	CameraMng::Init();
	SceneMng::Init(Scene_Title);
	Object::Initialize();
	pObjMng = new ObjMng();
}

Game::~Game()
{
	CameraMng::Destroy();
	SceneMng::Destroy();
	Object::UnInitialize();
	delete pObjMng;
}

void Game::FrameMove()
{
	pObjMng->FrameMove();
	CameraMng::Single()->SetCamera(Tool::tools.pd3dDevice);
}

void Game::FrameRender()
{
	pObjMng->FrameRender();

	//�V�[���ڍs�͍Ō�ɍs��
	SceneMng::Single()->LoadNextScene();
}
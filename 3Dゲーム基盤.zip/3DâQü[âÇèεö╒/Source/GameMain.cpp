//--------------------------------------------------------------------------------------
// File: GameMain.cpp
//
// Copyleft S.G.Kohata
//--------------------------------------------------------------------------------------

#include "Game.h"

Game* game_;
Light* worldlights[2];

void CreateDevice()
{
	CDebug::Create(Tool::tools.pd3dDevice);
	game_ = new Game();
	for (auto &light: worldlights) {
		light = new Light();
	}
}

//--------------------------------------------------------------------------------------
void DestroyDevice()
{
	CDebug::Release();
	delete game_;
	for (auto &light : worldlights) {
		delete light;
	}
}

//--------------------------------------------------------------------------------------
void ResetDevice()
{
	CDebug::Release();
	CDebug::Create(Tool::tools.pd3dDevice);
}

//--------------------------------------------------------------------------------------
void FrameMove()
{
	CDebug::Clear();
	game_->FrameMove();
}

//--------------------------------------------------------------------------------------
void FrameRender()
{
	//�����_�����O�p�̃��C�g�ݒ�
	for (int i = 0; i < 2; i++) {
		int angle = D3DXToRadian(i * 180);
		D3DXVECTOR3 direction(-cos(angle), 1, cos(angle));//�����w��(�����ł͐��K�����Ȃ�)

		D3DCOLORVALUE ambient;
		D3DCOLORVALUE diffuse;

		//�����̐F
		ambient.a = ambient.r = ambient.g = ambient.b = 0.4f;
		//���C�g�̐F
		diffuse.a = diffuse.r = diffuse.g = diffuse.b = 1.0f;

		worldlights[i]->LightOn(direction, ambient, diffuse, Tool::tools.pd3dDevice);
	}

	game_->FrameRender();
	CDebug::Render(0, 0);
}

#include "Object.h"

Object* Object::pTop = nullptr;

Object::Object(D3DXVECTOR3 InitPos)
{
	//�I�u�W�F�N�g���m�Ń��X�g�쐬���Ă���
	//���X�g�̐擪�X�V
	pNext = pTop;
	pTop = this;

	//�e�p�����[�^�����ݒ�
	Pos       = InitPos;
	Angle     = D3DXVECTOR3(0, 0, 0);
	Vec       = D3DXVECTOR3(0, 0, 0);
	IsAlphaOn = false;
	Mesh = nullptr;
	AnimeMesh = nullptr;
	D3DXMatrixIdentity(&Mat_Pos);
	D3DXMatrixIdentity(&Mat_Angle);
	D3DXMatrixIdentity(&Mat_Size);
}

Object::~Object()
{
	if (pTop)
		pTop = nullptr;
}

void Object::Initialize()
{
}

void Object::UnInitialize()
{
}

void Object::FrameMove()
{
}

void Object::MeshRender(CMeshExt * mesh)
{
	D3DXMATRIX mat_render, mat_bace;
	D3DXMatrixMultiply(&mat_bace, &Mat_Size, &Mat_Angle);
	D3DXMatrixMultiply(&mat_render, &mat_bace, &Mat_Pos);
	Tool::tools.pd3dDevice->SetTransform(D3DTS_WORLD, &mat_render);

	//�I�u�W�F�N�g�\��
	mesh->Render(Tool::tools.pd3dDevice);

	Tool::tools.pd3dDevice->SetRenderState(D3DRS_ZWRITEENABLE, true);
}

void Object::AnimeRender(CAnimation * anime)
{
	D3DXMATRIX mat_render, mat_bace;
	D3DXMatrixMultiply(&mat_bace, &Mat_Size, &Mat_Angle);
	D3DXMatrixMultiply(&mat_render, &mat_bace, &Mat_Pos);
	Tool::tools.pd3dDevice->SetTransform(D3DTS_WORLD, &mat_render);

	//�I�u�W�F�N�g�\��
	anime->Render(Tool::tools.pd3dDevice);

	Tool::tools.pd3dDevice->SetRenderState(D3DRS_ZWRITEENABLE, true);
}

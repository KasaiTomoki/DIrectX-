#include "SceneMng.h"

SceneMng* SceneMng::SingleTon = nullptr;

void SceneMng::Init(SceneList firstScene)
{
	SingleTon = new SceneMng(firstScene);
}

void SceneMng::Destroy()
{
	delete SingleTon;
}

SceneMng::SceneMng(SceneList firstScene)
{
	IsSceneChange = false;
	nScene = firstScene;
	nextScene = Scene_None;
}

SceneMng::~SceneMng()
{
}

void SceneMng::SetNextScene(SceneList next)
{
	nextScene = next;
	IsSceneChange = true;
}

void SceneMng::LoadNextScene()
{
	//�V�[���̈ڍs���s��(�ڍs����\��������ꍇ�̂�)
	if (IsSceneChange) {
		IsSceneChange = false;
		nScene = nextScene;
		nextScene = Scene_None;
	}
}

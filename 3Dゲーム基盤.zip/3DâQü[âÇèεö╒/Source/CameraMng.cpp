#include "CameraMng.h"

CameraMng* CameraMng::SingleTon = nullptr;

void CameraMng::Init()
{
	SingleTon = new CameraMng();
}

void CameraMng::Destroy()
{
	delete SingleTon;
}

CameraMng::CameraMng()
{
	vEye = D3DXVECTOR3(0, 0, 0);
	vAt = D3DXVECTOR3(0, 0, 1);
	vUp = D3DXVECTOR3(0, 1, 0);
}

CameraMng::~CameraMng()
{
}

void CameraMng::SetCamera(IDirect3DDevice9* device)
{
	D3DXMATRIXA16 matView;
	D3DXMatrixLookAtLH(&matView, &vEye, &vAt, &vUp);
	device->SetTransform(D3DTS_VIEW, &matView);
}

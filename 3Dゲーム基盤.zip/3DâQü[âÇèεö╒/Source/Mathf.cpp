#include "Mathf.h"

Mathf::Mathf()
{
}

Mathf::~Mathf()
{
}

D3DXVECTOR3 Mathf::AngleToVec(float angleX, float angleY, bool IgnoreY)
{
	float radiX = D3DXToRadian(angleX);
	float radiY = D3DXToRadian(angleY);

	D3DXVECTOR3 AtVec = D3DXVECTOR3(cos(radiY)*cos(radiX), sin(radiX), sin(radiY)*cos(radiX));

	//Y����̓����𖳎�����ꍇ
	if (IgnoreY)
		AtVec.y = 0;

	return *D3DXVec3Normalize(&AtVec, &AtVec);
}

D3DXVECTOR3 Mathf::AngleToVec(D3DXVECTOR3 angle, bool IgnoreY)
{
	return AngleToVec(angle.x, angle.y, IgnoreY);
}

D3DXVECTOR3 Mathf::VecToAngle(D3DXVECTOR3 vec)
{
	D3DXVECTOR3 toAngle;
	toAngle.x = D3DXToDegree(asin(vec.y));
	toAngle.y = D3DXToDegree(atan2(vec.z, vec.x));
	toAngle.z = 0;//Z���p�x�͂�������0�ŌŒ�

	return toAngle;
}

float Mathf::NormalRate(float num, float deno)
{
	float rate = num / deno;

	if (rate < 0)
		rate = 0;

	else if (rate > 1)
		rate = 1;

	return rate;
}

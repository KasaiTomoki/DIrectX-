#include "Light.h"

int Light::AllCount = 0;

Light::Light()
{
	MyNumber = AllCount;
	AllCount++;

	ZeroMemory(&UseLight, sizeof(D3DLIGHT9));
	UseLight.Type = D3DLIGHT_DIRECTIONAL;
}

Light::~Light()
{
	AllCount--;
	if (AllCount < 0)
		AllCount = 0;
}

void Light::LightOn(IDirect3DDevice9* device)
{
	device->SetLight(MyNumber, &UseLight);
	device->LightEnable(MyNumber, true);
}

void Light::LightOn(D3DXVECTOR3 direction, D3DCOLORVALUE ambient, D3DCOLORVALUE diffuse, IDirect3DDevice9* device)
{
	SetDirection(direction);
	SetAmbient(ambient);
	SetDiffuse(diffuse);

	LightOn(device);
}

void Light::LightOff(IDirect3DDevice9* device)
{
	device->LightEnable(MyNumber, false);
}

void Light::SetDirection(D3DXVECTOR3 direction)
{
	UseLight.Direction = direction;
}

void Light::SetAmbient(D3DCOLORVALUE ambient)
{
	UseLight.Ambient = ambient;
}

void Light::SetDiffuse(D3DCOLORVALUE diffuse)
{
	UseLight.Ambient = diffuse;
}

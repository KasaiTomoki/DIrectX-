//-----------------------------------------------------------------------------
// File: CResource.h
//
// Desc: ���\�[�X�̊Ǘ����s���x�[�X�N���X
// 													programmed by S.G.Kohata
//-----------------------------------------------------------------------------
#pragma once
class CResource {
protected:
	static CResource*		s_pTop;				// �Ǘ����
	CResource*				m_pNext;
	WCHAR					m_sType[256];

protected:
	HRESULT					CheckFileExist(WCHAR* pFilename);
	BOOL					IsSameType(WCHAR* pType);
							CResource(WCHAR* pType);
	virtual					~CResource();
};

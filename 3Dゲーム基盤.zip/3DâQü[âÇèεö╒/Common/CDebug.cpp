//-----------------------------------------------------------------------------
// File: CDebug.cpp
//
// Desc: �f�o�b�O���b�Z�[�W�̊Ǘ�
// 													programmed by S.G.Kohata
//-----------------------------------------------------------------------------
#include <stdio.h>
#include <d3d9.h>
#include <d3dx9.h>
#include "CDebug.h"

//-----------------------------------------------------------------------------
// Name:
// Desc:
//-----------------------------------------------------------------------------
CDebug* CDebug::s_pTop   = NULL;
ID3DXFont* CDebug::pFont = NULL;

void CDebug::Create(LPDIRECT3DDEVICE9 pd3dDevice)
{
	if (pFont == NULL) {
		D3DXCreateFont(pd3dDevice,
					   15,
					   0,
					   FW_NORMAL,
					   0,
					   FALSE,
					   DEFAULT_CHARSET, 
					   OUT_DEFAULT_PRECIS,
					   DEFAULT_QUALITY,
					   DEFAULT_PITCH | FF_DONTCARE, 
					   L"Terminal",
					   &pFont);
	}
}

void CDebug::Release()
{
	if (pFont) {
		pFont->Release();
		pFont = NULL;
	}
}

void CDebug::Clear()
{
	CDebug* pWork = s_pTop;
	while (pWork) {
		CDebug* pNext = pWork->m_pNext;
		delete [] pWork->m_pString;
		delete    pWork;
		pWork = pNext;
	}
	s_pTop = NULL;
}

void CDebug::AddText(WCHAR* fmt, ...)
{
	WCHAR buf[512];

	va_list	ap;

	va_start(ap, fmt);
	vswprintf(buf, sizeof(buf), fmt, ap);
	va_end(ap);

	// list�̍Ō������������
	if (s_pTop == NULL) {
		s_pTop = new CDebug;
		s_pTop->m_pNext = NULL;
		s_pTop->m_pString = new WCHAR[wcslen(buf)+1];
		wcscpy_s(s_pTop->m_pString, wcslen(buf)+1, buf);
	}
	else {
		CDebug* pWork = s_pTop;
		while (pWork->m_pNext) {
			pWork = pWork->m_pNext;
		}
		pWork->m_pNext = new CDebug;
		pWork->m_pNext->m_pNext = NULL;
		pWork->m_pNext->m_pString = new WCHAR[wcslen(buf)+1];
		wcscpy_s(pWork->m_pNext->m_pString, wcslen(buf)+1, buf);
	}
}

void CDebug::Render(int x, int y)
{
	RECT rct;
	ZeroMemory(&rct, sizeof(rct));
	rct.left   = x;
	rct.top	   = y;
	rct.right  = 1024;
	rct.bottom = 768;

	CDebug* pWork = s_pTop;
	while (pWork) {
		pFont->DrawText(NULL, pWork->m_pString, -1, &rct, 0, D3DCOLOR_ARGB(255, 255, 255, 255));
		rct.top += 12;
		pWork = pWork->m_pNext;
	}
	Clear();
}

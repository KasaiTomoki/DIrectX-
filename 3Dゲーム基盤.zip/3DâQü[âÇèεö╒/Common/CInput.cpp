#include "CInput.h"

LPDIRECTINPUT8			CInput::pDI;
LPDIRECTINPUTDEVICE8	CInput::pKeyboard;
LPDIRECTINPUTDEVICE8	CInput::pMouse;
BYTE					CInput::diksNow[256];	// ���݂̃L�[���
BYTE					CInput::diksOld[256];	// ���O�̃L�[���
DIMOUSESTATE2			CInput::dimsNow;		// ���݂̃}�E�X���
DIMOUSESTATE2			CInput::dimsOld;		// ���O�̃}�E�X���
POINT					CInput::dimpNow;		// ���݂̃}�E�X�ʒu
POINT					CInput::dimpOld;		// ���O�̃}�E�X�ʒu
POINT					CInput::windowOffset;	// �E�B���h�E�̈ʒu

CInput::CInput()
{
}

CInput::~CInput()
{
}


void CInput::Create()
{
	if (pDI)
		return;

	if (FAILED(DirectInput8Create(
							GetModuleHandle(NULL),
							DIRECTINPUT_VERSION,
							IID_IDirectInput8,
							(VOID**)&pDI,
							NULL)))
		return;

	// �L�[�{�[�h������
	if (FAILED(pDI->CreateDevice(GUID_SysKeyboard, &pKeyboard, NULL)))
		return;
	if (FAILED(pKeyboard->SetDataFormat(&c_dfDIKeyboard)))
		return;
	if (FAILED(pKeyboard->SetCooperativeLevel(
											DXUTGetHWND(), 
											DISCL_NONEXCLUSIVE | 
											DISCL_FOREGROUND | 
											DISCL_NOWINKEY)))
		return;
	pKeyboard->Acquire();

	if (FAILED(pDI->CreateDevice(GUID_SysMouse, &pMouse, NULL)))
		return;
	if (FAILED(pMouse->SetDataFormat(&c_dfDIMouse2)))
		return;
	if (FAILED(pMouse->SetCooperativeLevel(DXUTGetHWND(), DISCL_NONEXCLUSIVE | DISCL_FOREGROUND)))
		return;
	pMouse->Acquire();
}

void CInput::Destroy()
{
	SAFE_RELEASE(pMouse);
	SAFE_RELEASE(pKeyboard);
	SAFE_RELEASE(pDI);
}

void CInput::UpdateInput()
{
	HRESULT hr;

	// ���O��Ԃ̐ݒ�
	for (int i=0; i<256; i++)
		diksOld[i] = diksNow[i];

	// ���͏�Ԃ̃��Z�b�g
	ZeroMemory(diksNow, 256);

	// �L�[�{�[�h����
	hr = pKeyboard->GetDeviceState(256, diksNow);
	if(FAILED(hr)) {
		hr = pKeyboard->Acquire();
		while (hr == DIERR_INPUTLOST)
			hr = pKeyboard->Acquire();
	}

	// �}�E�X
	dimpOld = dimpNow;
	dimsOld = dimsNow;
	ZeroMemory(&dimsNow, sizeof(dimsNow));
    hr = pMouse->GetDeviceState(sizeof(DIMOUSESTATE2), &dimsNow);
	if(FAILED(hr)) {
		hr = pMouse->Acquire();
		while (hr == DIERR_INPUTLOST)
			hr = pMouse->Acquire();
	}

	// �}�E�X�̌��݈ʒu�擾
	POINT point;

	GetCursorPos(&point);
	// Window�̃^�C�g���T�C�Y�A�g�������v�Z����
	RECT  r       = {0, 0, DXUTGetWindowWidth(), DXUTGetWindowHeight()};
	AdjustWindowRect(&r, WS_OVERLAPPEDWINDOW, false);
	int   title   = -r.top;
	int   thick   = -r.left;
	GetWindowRect(DXUTGetHWND(), &r);

	// �v�Z���ʂ�����Window�ɑ΂���}�E�X�̈ʒu���v�Z����
	point.x -= (r.left + thick);
	point.y -= (r.top  + title);
	dimpNow.x = point.x;
	dimpNow.y = point.y;
	windowOffset.x = (r.left + thick);
	windowOffset.y = (r.top  + title);

}

BOOL CInput::IsKeyDown(int nKey)
{
	if ((diksOld[nKey] & 0x80) == 0 &&
		(diksNow[nKey] & 0x80) == 0x80)
		return TRUE;
	else
		return FALSE;
}

BOOL CInput::IsKeyUp(int nKey)
{
	if ((diksOld[nKey] & 0x80) == 0x80 &&
		(diksNow[nKey] & 0x80) == 0)
		return TRUE;
	else
		return FALSE;
}

BOOL CInput::IsKeyHold(int nKey)
{
	if ((diksNow[nKey] & 0x80) == 0x80)
		return TRUE;
	else
		return FALSE;
}

BOOL CInput::IsMouseDown(int nMouse)
{
	if ((dimsOld.rgbButtons[nMouse] & 0x80) == 0 &&
		(dimsNow.rgbButtons[nMouse] & 0x80) == 0x80)
		return TRUE;
	else
		return FALSE;
}

BOOL CInput::IsMouseUp(int nMouse)
{
	if ((dimsOld.rgbButtons[nMouse] & 0x80) == 0x80 &&
		(dimsNow.rgbButtons[nMouse] & 0x80) == 0)
		return TRUE;
	else
		return FALSE;
}

BOOL CInput::IsMouseHold(int nMouse)
{
	if ((dimsNow.rgbButtons[nMouse] & 0x80) == 0x80)
		return TRUE;
	else
		return FALSE;
}

POINT CInput::GetMousePos()
{
	return dimpNow;
}


//-----------------------------------------------------------------------------
// File: CDebug.h
//
// Desc: �f�o�b�O���b�Z�[�W�̊Ǘ�
// 													programmed by S.G.Kohata
//-----------------------------------------------------------------------------
#pragma once
class CDebug {
	static CDebug*			s_pTop;				// �Ǘ����
	CDebug*					m_pNext;
	WCHAR*					m_pString;
	static ID3DXFont*		pFont;
public:
	static void				Create(LPDIRECT3DDEVICE9 pd3dDevice);
	static void				Release();
	static void				Clear();
	static void				AddText(WCHAR* fmt,...);
	static void				Render(int x, int y);
};

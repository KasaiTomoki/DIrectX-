//--------------------------------------------------------------------------------------
// File: CAnimation.cpp
//
// Copyright (c) S.G.Kohata. All rights reserved.
//--------------------------------------------------------------------------------------
#undef POINTER_64
#undef _CRT_SECURE_NO_DEPRECATE
#define POINTER_64 __ptr64
#define _CRT_SECURE_NO_DEPRECATE
#include <tchar.h>
#include "CAnimation.h"

CAnimation::CAnimation(IDirect3DDevice9* pd3dDevice, const WCHAR* pFilename)
: CResource(L"CAnimation")
{
	// �n�߂̃g���b�N
	m_nAnimationTrack    = 0;
	m_nAnimationTrackOld = 0;

	// �A�j���[�V��������
	m_fChangeTime  = 0;
	m_fTime        = 0;
	m_fTimeOld     = 0;
	m_fStopTime    = -1;
	m_fStopTimeOld = -1;
	m_fSpeed       = float(30/4800.0);
	m_fRadius      = 0;
	m_sCenter      = D3DXVECTOR3(0, 0, 0);
	m_nVertices    = 0;

	// ���ɓ������̂���������������
	BOOL        bFind = FALSE;
	CAnimation* pWork = (CAnimation*)s_pTop;
	while (pWork) {
		// ����̃t�@�C������?
		if (pWork != this &&
			pWork->IsSameType(m_sType) &&
			wcscmp(pFilename, pWork->m_pAnimation->pFilename) == 0) {
			bFind      = TRUE;
			// �����ꏊ�����L����̂�
			m_pAnimation = pWork->m_pAnimation;
			break;
		}
		pWork = (CAnimation*)pWork->m_pNext;
	}
	// ������Ȃ������ꍇ�͒ǉ�����
	if (!bFind) {
		m_pAnimation         = new animation_t;
		m_pAnimation->nCount = 0;
		Create(pd3dDevice, pFilename);
	}

	// �Q�ƃJ�E���^�𑝉�����
	m_pAnimation->nCount++;
}

CAnimation::~CAnimation()
{
	// �Q�ƃJ�E���^�����炷
	m_pAnimation->nCount--;

	// �Q�ƃJ�E���^��0�̏ꍇ�͒N������g�p����Ă��Ȃ��̂ŁA�������
	// ���������X�g�̂��߁A���ӂ���
	if (m_pAnimation->nCount <= 0)
		// �f�[�^�����
		Destroy();
}

void CAnimation::Create(LPDIRECT3DDEVICE9 pd3dDevice, const WCHAR* pFilename)
{
	m_pAnimation->pFilename = new WCHAR[wcslen(pFilename)+1];
	wcscpy_s(m_pAnimation->pFilename, wcslen(pFilename)+1, pFilename);

	m_pAnimation->_pFrameRoot      = NULL;
	m_pAnimation->_pAnimController = NULL;

    D3DXLoadMeshHierarchyFromX(pFilename,
    						   D3DXMESH_MANAGED,
    						   pd3dDevice,
    						   &m_pAnimation->_alloc,
    						   NULL,
    						   &m_pAnimation->_pFrameRoot,
    						   &m_pAnimation->_pAnimController);
    SetupBoneMatrixPointers(m_pAnimation->_pFrameRoot);
	ComputeBoundingSphere(NULL);
}

void CAnimation::Destroy()
{
    ReleaseAttributeTable(m_pAnimation->_pFrameRoot);
    D3DXFrameDestroy(m_pAnimation->_pFrameRoot, &m_pAnimation->_alloc);
    SAFE_RELEASE(m_pAnimation->_pAnimController);
	delete [] m_pAnimation->pFilename;
	delete m_pAnimation;
}

void CAnimation::SetSpeed(float speed)
{
	m_fSpeed = speed;
}

void CAnimation::SetTime(float fElapsedTime)
{
	if (m_fStopTime == -1)
		m_fTime += fElapsedTime*m_fSpeed;
	else {
		m_fTime += fElapsedTime*m_fSpeed;
		if (m_fTime >= m_fStopTime*m_fSpeed)
			m_fTime = m_fStopTime*m_fSpeed;
	}

	if (m_fStopTimeOld == -1)
		m_fTimeOld += fElapsedTime*m_fSpeed;
	else {
		m_fTimeOld += fElapsedTime*m_fSpeed;
		if (m_fTimeOld >= m_fStopTimeOld*m_fSpeed)
			m_fTimeOld = m_fStopTimeOld*m_fSpeed;
	}

	// �A�j���[�V�����ύX���s���Ă���Œ����H
	if (m_fChangeTime > 0) {
		m_fChangeTime -= fElapsedTime;
		if (m_fChangeTime <= 0) {
			m_pAnimation->_pAnimController->SetTrackEnable(0, true);
			m_pAnimation->_pAnimController->SetTrackEnable(1, false);
			m_pAnimation->_pAnimController->SetTrackWeight(0, 1);
			m_pAnimation->_pAnimController->SetTrackWeight(1, 0);
			m_nAnimationTrackOld = m_nAnimationTrack;
		}
		else {
			float w = m_fChangeTime/m_fChangeTimeBase;
			m_pAnimation->_pAnimController->SetTrackWeight(0, 1-w);
			m_pAnimation->_pAnimController->SetTrackWeight(1, w);
		}
	}
	else {
		m_pAnimation->_pAnimController->SetTrackWeight(0, 1);
		m_pAnimation->_pAnimController->SetTrackWeight(1, 0);
	}

	LPD3DXANIMATIONSET p;
	m_pAnimation->_pAnimController->GetAnimationSet(m_nAnimationTrackOld, &p);
	m_pAnimation->_pAnimController->SetTrackAnimationSet(1, p);
	p->Release();

	m_pAnimation->_pAnimController->GetAnimationSet(m_nAnimationTrack, &p);
	m_pAnimation->_pAnimController->SetTrackAnimationSet(0, p);
	p->Release();

	if(m_pAnimation->_pAnimController != NULL) {
		m_pAnimation->_pAnimController->SetTrackPosition(0, m_fTime);
		m_pAnimation->_pAnimController->SetTrackPosition(1, m_fTimeOld);
		//for (UINT i = 0;i < m_pAnimation->_pAnimController->GetMaxNumTracks(); i++)
		//	m_pAnimation->_pAnimController->SetTrackPosition(i, m_fTime);
		m_pAnimation->_pAnimController->AdvanceTime(0, NULL);
	}
}

void CAnimation::ResetTime()
{
	m_fTime = 0;
	for (UINT i = 0;i < m_pAnimation->_pAnimController->GetMaxNumTracks(); i++)
		m_pAnimation->_pAnimController->SetTrackPosition(i, 0);
	m_pAnimation->_pAnimController->AdvanceTime(0, NULL);
}

void CAnimation::ChangeAnimation(UINT track, float time, float endTime)
{
	if (track < 0 ||
		track >= GetTracks() ||
		m_nAnimationTrack == track)
		return;

	LPD3DXANIMATIONSET p;

	m_fTimeOld     = m_fTime;
	m_fTime        = 0;
	m_fStopTimeOld = m_fStopTime;
	m_fStopTime    = endTime;

	// ���ݍĐ����̃g���b�N���P�ցiMix�p)
	m_pAnimation->_pAnimController->GetAnimationSet(m_nAnimationTrack, &p);
	m_pAnimation->_pAnimController->SetTrackAnimationSet(1, p);
	p->Release();

	// �V�����g���b�N���O��(Mix�p)
	m_pAnimation->_pAnimController->GetAnimationSet(track, &p);
	m_pAnimation->_pAnimController->SetTrackAnimationSet(0, p);
	p->Release();

	if (time == 0) {
		m_fChangeTimeBase = 1;
		m_fChangeTime     = 0;
	}
	else {
		m_fChangeTimeBase = time;
		m_fChangeTime     = time;
	}
	m_pAnimation->_pAnimController->SetTrackEnable(0, true);
	m_pAnimation->_pAnimController->SetTrackEnable(1, true);
	m_pAnimation->_pAnimController->SetTrackWeight(0, 0);
	m_pAnimation->_pAnimController->SetTrackWeight(1, 1);

	m_nAnimationTrackOld = m_nAnimationTrack;
	m_nAnimationTrack    = track;
}

UINT CAnimation::GetTracks()
{
	if (m_pAnimation->_pAnimController)
		return m_pAnimation->_pAnimController->GetMaxNumAnimationSets();
	else
		return 0;
}

//--------------------------------------------------------------------------------------
// Called to render a mesh in the hierarchy
//--------------------------------------------------------------------------------------
void CAnimation::DrawMeshContainer(IDirect3DDevice9 *pd3dDevice, LPD3DXMESHCONTAINER pMeshContainerBase, LPD3DXFRAME pFrameBase)
{
    HRESULT hr;
    D3DXMESHCONTAINER_DERIVED *pMeshContainer = (D3DXMESHCONTAINER_DERIVED*)pMeshContainerBase;
    D3DXFRAME_DERIVED *pFrame = (D3DXFRAME_DERIVED*)pFrameBase;
    UINT iMaterial;
    UINT NumBlend;
    UINT iAttrib;
    DWORD AttribIdPrev;
    LPD3DXBONECOMBINATION pBoneComb;

    UINT iMatrixIndex;
    D3DXMATRIXA16 matTemp;
    D3DCAPS9 d3dCaps;
    pd3dDevice->GetDeviceCaps(&d3dCaps);

    // first check for skinning
    if (pMeshContainer->pSkinInfo != NULL)
    {
        AttribIdPrev = UNUSED32; 
        pBoneComb = reinterpret_cast<LPD3DXBONECOMBINATION>(pMeshContainer->pBoneCombinationBuf->GetBufferPointer());

        // Draw using default vtx processing of the device (typically HW)
        for (iAttrib = 0; iAttrib < pMeshContainer->NumAttributeGroups; iAttrib++)
        {
            NumBlend = 0;
            for (DWORD i = 0; i < pMeshContainer->NumInfl; ++i)
            {
                if (pBoneComb[iAttrib].BoneId[i] != UINT_MAX)
                {
                    NumBlend = i;
                }
            }

            if(d3dCaps.MaxVertexBlendMatrices >= NumBlend + 1)
            {
                // first calculate the world matrices for the current set of blend weights and get the accurate count of the number of blends
                for (DWORD i = 0; i < pMeshContainer->NumInfl; ++i)
                {
                    iMatrixIndex = pBoneComb[iAttrib].BoneId[i];
                    if (iMatrixIndex != UINT_MAX)
                    {
                        D3DXMatrixMultiply(&matTemp, &pMeshContainer->pBoneOffsetMatrices[iMatrixIndex], pMeshContainer->ppBoneMatrixPtrs[iMatrixIndex]);
                        V(pd3dDevice->SetTransform(D3DTS_WORLDMATRIX(i), &matTemp));
                    }
                }

                V(pd3dDevice->SetRenderState(D3DRS_VERTEXBLEND, NumBlend));

                // lookup the material used for this subset of faces
                if ((AttribIdPrev != pBoneComb[iAttrib].AttribId) || (AttribIdPrev == UNUSED32))
                {
					CopyMaterialDiffuseToAmbient(&pMeshContainer->pMaterials[pBoneComb[iAttrib].AttribId].MatD3D);
					V(pd3dDevice->SetMaterial(&pMeshContainer->pMaterials[pBoneComb[iAttrib].AttribId].MatD3D));
                    V(pd3dDevice->SetTexture(0, pMeshContainer->ppTextures[pBoneComb[iAttrib].AttribId]));
                    AttribIdPrev = pBoneComb[iAttrib].AttribId;
                }

                // draw the subset now that the correct material and matrices are loaded
                V(pMeshContainer->MeshData.pMesh->DrawSubset(iAttrib));
            }
        }

        // If necessary, draw parts that HW could not handle using SW
        if (pMeshContainer->iAttributeSW < pMeshContainer->NumAttributeGroups)
        {
            AttribIdPrev = UNUSED32; 
            V(pd3dDevice->SetSoftwareVertexProcessing(TRUE));
            for (iAttrib = pMeshContainer->iAttributeSW; iAttrib < pMeshContainer->NumAttributeGroups; iAttrib++)
            {
                NumBlend = 0;
                for (DWORD i = 0; i < pMeshContainer->NumInfl; ++i)
                {
                    if (pBoneComb[iAttrib].BoneId[i] != UINT_MAX)
                    {
                        NumBlend = i;
                    }
                }

                if (d3dCaps.MaxVertexBlendMatrices < NumBlend + 1)
                {
                    // first calculate the world matrices for the current set of blend weights and get the accurate count of the number of blends
                    for (DWORD i = 0; i < pMeshContainer->NumInfl; ++i)
                    {
                        iMatrixIndex = pBoneComb[iAttrib].BoneId[i];
                        if (iMatrixIndex != UINT_MAX)
                        {
                            D3DXMatrixMultiply(&matTemp, &pMeshContainer->pBoneOffsetMatrices[iMatrixIndex], pMeshContainer->ppBoneMatrixPtrs[iMatrixIndex]);
                            V(pd3dDevice->SetTransform(D3DTS_WORLDMATRIX(i), &matTemp));
                        }
                    }

                    V(pd3dDevice->SetRenderState(D3DRS_VERTEXBLEND, NumBlend));

                    // lookup the material used for this subset of faces
                    if ((AttribIdPrev != pBoneComb[iAttrib].AttribId) || (AttribIdPrev == UNUSED32))
                    {
						CopyMaterialDiffuseToAmbient(&pMeshContainer->pMaterials[pBoneComb[iAttrib].AttribId].MatD3D);
                        V(pd3dDevice->SetMaterial(&pMeshContainer->pMaterials[pBoneComb[iAttrib].AttribId].MatD3D));
                        V(pd3dDevice->SetTexture(0, pMeshContainer->ppTextures[pBoneComb[iAttrib].AttribId]));
                        AttribIdPrev = pBoneComb[iAttrib].AttribId;
                    }

                    // draw the subset now that the correct material and matrices are loaded
                    V(pMeshContainer->MeshData.pMesh->DrawSubset(iAttrib));
                }
            }
            V(pd3dDevice->SetSoftwareVertexProcessing(FALSE));
        }

        V(pd3dDevice->SetRenderState(D3DRS_VERTEXBLEND, 0));
    }
    else  // standard mesh, just draw it after setting material properties
    {
        V(pd3dDevice->SetTransform(D3DTS_WORLD, &pFrame->CombinedTransformationMatrix));

        for (iMaterial = 0; iMaterial < pMeshContainer->NumMaterials; iMaterial++)
        {
			CopyMaterialDiffuseToAmbient(&pMeshContainer->pMaterials[iMaterial].MatD3D);
            V(pd3dDevice->SetMaterial(&pMeshContainer->pMaterials[iMaterial].MatD3D));
            V(pd3dDevice->SetTexture(0, pMeshContainer->ppTextures[iMaterial]));
            V(pMeshContainer->MeshData.pMesh->DrawSubset(iMaterial));
        }
    }
}

//--------------------------------------------------------------------------------------
// Called to render a frame in the hierarchy
//--------------------------------------------------------------------------------------
void CAnimation::Render(IDirect3DDevice9 *pd3dDevice, LPD3DXFRAME pFrame)
{
	if (!pFrame) {
		pFrame = m_pAnimation->_pFrameRoot;
		D3DXMATRIX matWorld;
		pd3dDevice->GetTransform(D3DTS_WORLD, &matWorld);
		UpdateFrameMatrices(&matWorld);
	}

	LPD3DXMESHCONTAINER pMeshContainer;

    pMeshContainer = pFrame->pMeshContainer;
    while (pMeshContainer != NULL)
    {
        DrawMeshContainer(pd3dDevice, pMeshContainer, pFrame);

        pMeshContainer = pMeshContainer->pNextMeshContainer;
    }

    if (pFrame->pFrameSibling != NULL)
    {
        Render(pd3dDevice, pFrame->pFrameSibling);
    }

    if (pFrame->pFrameFirstChild != NULL)
    {
        Render(pd3dDevice, pFrame->pFrameFirstChild);
    }
}


//--------------------------------------------------------------------------------------
// Called to setup the pointers for a given bone to its transformation matrix
//--------------------------------------------------------------------------------------
HRESULT CAnimation::SetupBoneMatrixPointersOnMesh(LPD3DXMESHCONTAINER pMeshContainerBase)
{
    UINT iBone, cBones;
    D3DXFRAME_DERIVED *pFrame;

    D3DXMESHCONTAINER_DERIVED *pMeshContainer = (D3DXMESHCONTAINER_DERIVED*)pMeshContainerBase;

    // if there is a skinmesh, then setup the bone matrices
    if (pMeshContainer->pSkinInfo != NULL)
    {
        cBones = pMeshContainer->pSkinInfo->GetNumBones();

        pMeshContainer->ppBoneMatrixPtrs = new D3DXMATRIX*[cBones];
        if (pMeshContainer->ppBoneMatrixPtrs == NULL)
            return E_OUTOFMEMORY;

        for (iBone = 0; iBone < cBones; iBone++)
        {
            pFrame = (D3DXFRAME_DERIVED*)D3DXFrameFind(m_pAnimation->_pFrameRoot, pMeshContainer->pSkinInfo->GetBoneName(iBone));
            if (pFrame == NULL)
                return E_FAIL;

            pMeshContainer->ppBoneMatrixPtrs[iBone] = &pFrame->CombinedTransformationMatrix;
        }
    }

    return S_OK;
}


//--------------------------------------------------------------------------------------
// Called to setup the pointers for a given bone to its transformation matrix
//--------------------------------------------------------------------------------------
HRESULT CAnimation::SetupBoneMatrixPointers(LPD3DXFRAME pFrame)
{
	HRESULT hr;

    if (pFrame->pMeshContainer != NULL)
    {
        hr = SetupBoneMatrixPointersOnMesh(pFrame->pMeshContainer);
        if (FAILED(hr))
            return hr;
    }

    if (pFrame->pFrameSibling != NULL)
    {
        hr = SetupBoneMatrixPointers(pFrame->pFrameSibling);
        if (FAILED(hr))
            return hr;
    }

    if (pFrame->pFrameFirstChild != NULL)
    {
        hr = SetupBoneMatrixPointers(pFrame->pFrameFirstChild);
        if (FAILED(hr))
            return hr;
    }

    return S_OK;
}




//--------------------------------------------------------------------------------------
// update the frame matrices
//--------------------------------------------------------------------------------------
void CAnimation::UpdateFrameMatrices(LPD3DXMATRIX pParentMatrix, LPD3DXFRAME pFrameBase)
{
	// ���[�V�����̍Đݒ�
	SetTime(0);

	if (!pFrameBase)
		pFrameBase = m_pAnimation->_pFrameRoot;
    D3DXFRAME_DERIVED *pFrame = (D3DXFRAME_DERIVED*)pFrameBase;

    if (pParentMatrix != NULL)
        D3DXMatrixMultiply(&pFrame->CombinedTransformationMatrix, &pFrame->TransformationMatrix, pParentMatrix);
    else
        pFrame->CombinedTransformationMatrix = pFrame->TransformationMatrix;

    if (pFrame->pFrameSibling != NULL)
    {
        UpdateFrameMatrices(pParentMatrix, pFrame->pFrameSibling);
    }

    if (pFrame->pFrameFirstChild != NULL)
    {
        UpdateFrameMatrices(&pFrame->CombinedTransformationMatrix, pFrame->pFrameFirstChild);
    }
}


//--------------------------------------------------------------------------------------
// update the skinning method
//--------------------------------------------------------------------------------------
void CAnimation::UpdateSkinningMethod(LPD3DXFRAME pFrameBase)
{
    D3DXFRAME_DERIVED *pFrame = (D3DXFRAME_DERIVED*)pFrameBase;
    D3DXMESHCONTAINER_DERIVED *pMeshContainer;

    pMeshContainer = (D3DXMESHCONTAINER_DERIVED *)pFrame->pMeshContainer;

    while(pMeshContainer != NULL)
    {
        m_pAnimation->_alloc.GenerateSkinnedMesh(DXUTGetD3D9Device(), pMeshContainer);

        pMeshContainer = (D3DXMESHCONTAINER_DERIVED *)pMeshContainer->pNextMeshContainer;
    }

    if (pFrame->pFrameSibling != NULL)
    {
        UpdateSkinningMethod(pFrame->pFrameSibling);
    }

    if (pFrame->pFrameFirstChild != NULL)
    {
        UpdateSkinningMethod(pFrame->pFrameFirstChild);
    }
}


void CAnimation::ReleaseAttributeTable(LPD3DXFRAME pFrameBase)
{
    D3DXFRAME_DERIVED *pFrame = (D3DXFRAME_DERIVED*)pFrameBase;
    D3DXMESHCONTAINER_DERIVED *pMeshContainer;

    pMeshContainer = (D3DXMESHCONTAINER_DERIVED *)pFrame->pMeshContainer;

    while(pMeshContainer != NULL)
    {
        delete[] pMeshContainer->pAttributeTable;

        pMeshContainer = (D3DXMESHCONTAINER_DERIVED *)pMeshContainer->pNextMeshContainer;
    }

    if (pFrame->pFrameSibling != NULL)
    {
        ReleaseAttributeTable(pFrame->pFrameSibling);
    }

    if (pFrame->pFrameFirstChild != NULL)
    {
        ReleaseAttributeTable(pFrame->pFrameFirstChild);
    }
}

void CAnimation::ComputeBoundingSphere(LPD3DXFRAME pFrameBase)
{
	BOOL bFirst = FALSE;
	BOOL bComputeFirst = TRUE;
	D3DXVECTOR3 sMinPos;
	D3DXVECTOR3 sMaxPos;

	if (pFrameBase == NULL) {
		bFirst      = TRUE;
		pFrameBase  = m_pAnimation->_pFrameRoot;
		m_sCenter   = D3DXVECTOR3(0, 0, 0);
		m_nVertices = 0;
	}

	// ���E���̌v�Z
	if (pFrameBase) {
		LPD3DXMESHCONTAINER pD3DXMeshContainer;
		pD3DXMeshContainer = pFrameBase->pMeshContainer;
		while (pD3DXMeshContainer) {
			D3DXMESHCONTAINER *pCD3DXMesh = (D3DXMESHCONTAINER*)pD3DXMeshContainer;
			D3DXVECTOR3* pVertex;
			if (pCD3DXMesh->MeshData.pMesh) {
				pCD3DXMesh->MeshData.pMesh->LockVertexBuffer(D3DLOCK_READONLY, (LPVOID*)&pVertex);
				int vertices = pCD3DXMesh->MeshData.pMesh->GetNumVertices();
				int stride   = D3DXGetFVFVertexSize(pCD3DXMesh->MeshData.pMesh->GetFVF());
				while (vertices-- > 0) {
					m_sCenter += pVertex[0];
					m_nVertices++;

					if (bComputeFirst) {
						bComputeFirst = FALSE;
						sMinPos = D3DXVECTOR3(pVertex[0].x, pVertex[0].y, pVertex[0].z);
						sMaxPos = D3DXVECTOR3(pVertex[0].x, pVertex[0].y, pVertex[0].z);
					}
					else {
						if (sMinPos.x > pVertex[0].x) sMinPos.x = pVertex[0].x;
						if (sMinPos.y > pVertex[0].y) sMinPos.y = pVertex[0].y;
						if (sMinPos.z > pVertex[0].z) sMinPos.z = pVertex[0].z;
						if (sMaxPos.x < pVertex[0].x) sMaxPos.x = pVertex[0].x;
						if (sMaxPos.y < pVertex[0].y) sMaxPos.y = pVertex[0].y;
						if (sMaxPos.z < pVertex[0].z) sMaxPos.z = pVertex[0].z;
					}
					float f = float(sqrt(pVertex[0].x*pVertex[0].x+
										 pVertex[0].y*pVertex[0].y+
										 pVertex[0].z*pVertex[0].z));
					if (f > m_fRadius)
						m_fRadius = f;
					pVertex = (D3DXVECTOR3*)(((BYTE*)pVertex)+stride);
				}
				pCD3DXMesh->MeshData.pMesh->UnlockVertexBuffer();
			}
			pD3DXMeshContainer = pD3DXMeshContainer->pNextMeshContainer;
		}
	}

	if (pFrameBase) {
		if (pFrameBase->pFrameFirstChild)
			ComputeBoundingSphere(pFrameBase->pFrameFirstChild);
		if (pFrameBase->pFrameSibling)
			ComputeBoundingSphere(pFrameBase->pFrameSibling);
	}

	if (bFirst) {
		if (m_nVertices > 0)
			m_sCenter /= float(m_nVertices);
	}
}

FLOAT CAnimation::GetRadius()
{
	return m_fRadius;
}

D3DXVECTOR3* CAnimation::GetCenter()
{
	return &m_sCenter;
}

void CAnimation::CopyMaterialDiffuseToAmbient(D3DMATERIAL9* pMaterial)
{
	pMaterial->Ambient = pMaterial->Diffuse;
}

D3DXMATRIX*	CAnimation::GetMatrix(char *pName, D3DXFRAME_DERIVED *pParent, D3DXMATRIX *pMat)
{
	if (!pParent) {
		pParent = (D3DXFRAME_DERIVED*)m_pAnimation->_pFrameRoot;
	}

	D3DXFRAME_DERIVED* pWork = pParent;
	while(pWork){
		if(strcmp(pName,pWork->Name) == 0)
			return &pWork->CombinedTransformationMatrix;

		if(pWork->pFrameFirstChild){
			D3DXMATRIX* pMat = GetMatrix(pName,(D3DXFRAME_DERIVED*)pWork->pFrameFirstChild);
			if(pMat)
				return pMat;
		}
		pWork = (D3DXFRAME_DERIVED*)pWork->pFrameSibling;
	}

	return NULL;
}

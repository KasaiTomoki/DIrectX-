//-----------------------------------------------------------------------------
// File: CCamera.cpp
//
// Desc: �J�����̊Ǘ�
//-----------------------------------------------------------------------------
#undef POINTER_64
#undef _CRT_SECURE_NO_DEPRECATE
#define POINTER_64 __ptr64
#define _CRT_SECURE_NO_DEPRECATE
#include <tchar.h>
#include <stdio.h>
#include <d3d9.h>
#include <d3dx9.h>
#include <assert.h>
#include "CCamera.h"

//-----------------------------------------------------------------------------
// Name:
// Desc:
//-----------------------------------------------------------------------------
CCamera::CCamera()
{
    // Set attributes for the view matrix
    SetViewParams( D3DXVECTOR3(0.0f,0.0f,0.0f), D3DXVECTOR3(0.0f,0.0f,1.0f),
                   D3DXVECTOR3(0.0f,1.0f,0.0f) );

    // Set attributes for the projection matrix
    SetProjParams( D3DX_PI/4, 1.0f, 1.0f, 10000.0f );

	// Set viewport
	SetViewPort(0, 0, 640, 480);
}

//-----------------------------------------------------------------------------
// Name:
// Desc:
//-----------------------------------------------------------------------------
VOID CCamera::SetViewPort(int x, int y, int width, int height)
{
	m_viewport.X		= x;
	m_viewport.Y		= y;
	m_viewport.Width	= width;
	m_viewport.Height	= height;
	m_viewport.MinZ		= 0;
	m_viewport.MaxZ		= 1;
}

//-----------------------------------------------------------------------------
// Name:
// Desc:
//-----------------------------------------------------------------------------
VOID CCamera::SetViewParams( D3DXVECTOR3 &vEyePt, D3DXVECTOR3& vLookatPt, D3DXVECTOR3& vUpVec )
{
    // Set attributes for the view matrix
    m_vEyePt    = vEyePt;
    m_vLookatPt = vLookatPt;
    m_vUpVec    = vUpVec;
    D3DXVec3Normalize( &m_vView, &(m_vLookatPt - m_vEyePt) );
    D3DXVec3Cross( &m_vCross, &m_vView, &m_vUpVec );

    D3DXMatrixLookAtLH( &m_matView, &m_vEyePt, &m_vLookatPt, &m_vUpVec );
    D3DXMatrixInverse( &m_matBillboard, NULL, &m_matView );
    m_matBillboard._41 = 0.0f;
    m_matBillboard._42 = 0.0f;
    m_matBillboard._43 = 0.0f;
}

//-----------------------------------------------------------------------------
// Name:
// Desc:
//-----------------------------------------------------------------------------
VOID CCamera::SetProjParams( FLOAT fFOV, FLOAT fAspect, FLOAT fNearPlane, FLOAT fFarPlane )
{
    // Set attributes for the projection matrix
    m_fFOV        = fFOV;
    m_fAspect     = fAspect;
    m_fNearPlane  = fNearPlane;
    m_fFarPlane   = fFarPlane;

    D3DXMatrixPerspectiveFovLH( &m_matProj, fFOV, fAspect, fNearPlane, fFarPlane );
}

//-----------------------------------------------------------------------------
// Name:
// Desc:
//-----------------------------------------------------------------------------
VOID CCamera::CalcFrustum()
{
	float	x1 = (float)m_viewport.X,
			y1 = (float)m_viewport.Y,
			x2 = (float)m_viewport.X + (float)m_viewport.Width,
			y2 = (float)m_viewport.Y + (float)m_viewport.Height;
#if 0
	m_nearPoint[0] = D3DXVECTOR3(x1, y1, 0);
	m_nearPoint[1] = D3DXVECTOR3(x2, y1, 0);
	m_nearPoint[2] = D3DXVECTOR3(x1, y2, 0);
	m_nearPoint[3] = D3DXVECTOR3(x2, y2, 0);
	m_farPoint [0] = D3DXVECTOR3(x1, y1, 1);
	m_farPoint [1] = D3DXVECTOR3(x2, y1, 1);
	m_farPoint [2] = D3DXVECTOR3(x1, y2, 1);
	m_farPoint [3] = D3DXVECTOR3(x2, y2, 1);
#else
	x1 += 100;
	y1 += 100;
	x2 -= 100;
	y2 -= 100;
	m_nearPoint[0] = D3DXVECTOR3(x1, y1, 0.9f);
	m_nearPoint[1] = D3DXVECTOR3(x2, y1, 0.9f);
	m_nearPoint[2] = D3DXVECTOR3(x1, y2, 0.9f);
	m_nearPoint[3] = D3DXVECTOR3(x2, y2, 0.9f);
	m_farPoint [0] = D3DXVECTOR3(x1, y1, 0.9991f);
	m_farPoint [1] = D3DXVECTOR3(x2, y1, 0.9991f);
	m_farPoint [2] = D3DXVECTOR3(x1, y2, 0.9991f);
	m_farPoint [3] = D3DXVECTOR3(x2, y2, 0.9991f);
#endif
	// ������̂W�_�̌v�Z
	D3DXMATRIX world;
	D3DXMatrixIdentity(&world);
	for (int n = 0; n < 4; n++) {
		D3DXVec3Unproject(&m_nearPoint[n], &m_nearPoint[n], &m_viewport, &m_matProj, &m_matView, &world);
		D3DXVec3Unproject(&m_farPoint [n], &m_farPoint [n], &m_viewport, &m_matProj, &m_matView, &world);
	}
	// ������̖@���̌v�Z
	// ���̕�
	D3DXVec3Cross(&m_normal[0], &(m_farPoint [1]-m_farPoint [0]), &(m_farPoint [2]-m_farPoint [0]));
	// �O�̕�
	D3DXVec3Cross(&m_normal[1], &(m_nearPoint[2]-m_nearPoint[0]), &(m_nearPoint[1]-m_nearPoint[0]));
	// ���̕�
	D3DXVec3Cross(&m_normal[2], &(m_farPoint [2]-m_farPoint [0]), &(m_nearPoint[0]-m_farPoint [0]));
	// ��̕�
	D3DXVec3Cross(&m_normal[3], &(m_nearPoint[0]-m_farPoint [0]), &(m_farPoint [1]-m_farPoint [0]));
	// �E�̕�
	D3DXVec3Cross(&m_normal[4], &(m_nearPoint[1]-m_farPoint [1]), &(m_farPoint [3]-m_farPoint [1]));
	// ���̕�
	D3DXVec3Cross(&m_normal[5], &(m_farPoint [3]-m_farPoint [2]), &(m_nearPoint[2]-m_farPoint [2]));
	// ���K��
	for (int i = 0; i < 6; i++)
		D3DXVec3Normalize(&m_normal[i], &m_normal[i]);

	// �������Ax+By+Cz+d=0
	m_planeD[0] = CalcD(m_farPoint [0], m_normal[0]);
	m_planeD[1] = CalcD(m_nearPoint[0], m_normal[1]);
	m_planeD[2] = CalcD(m_farPoint [0], m_normal[2]);
	m_planeD[3] = CalcD(m_farPoint [0], m_normal[3]);
	m_planeD[4] = CalcD(m_farPoint [1], m_normal[4]);
	m_planeD[5] = CalcD(m_farPoint [2], m_normal[5]);
}

//-----------------------------------------------------------------------------
// Name:
// Desc:
//-----------------------------------------------------------------------------
BOOL CCamera::IsVisible(D3DXVECTOR3& point, FLOAT bounding)
{
	int n = CalcCrossPoint(point, NULL);
	// �S�Ă̕ǂ̗��ɋ��Ȃ��ꍇ�͓����Ȃ̂ŕ\��
	if (n == 0)
		return true;

	// �O���̏ꍇ�͑S�Ă̕ǂ̋������v�Z��
	// �S��bounding�ȉ��̏ꍇ�͕\��
	while (n--) {
		if (D3DXVec3Length(&(point-m_crossPoint[n])) > bounding)
			return false;
	}

	return true;
}

//-----------------------------------------------------------------------------
// Name:
// Desc:
//-----------------------------------------------------------------------------
int CCamera::CalcCrossPoint(D3DXVECTOR3& point, D3DXVECTOR3** crosspoint)
{
	int nCross = 0;

	// ���̕�
	// �O�̕�
	// ���̕�
	// ��̕�
	// �E�̕�
	// ���̕�
	for (int n = 0; n < 6; n++) {
		if (IsPointBehind(point, m_normal[n], m_planeD[n])) {
			m_crossPoint[nCross] = CalcCrossPoint(point, m_normal[n], -m_normal[n], m_planeD[n]);
			nCross++;
		}
	}

	if (crosspoint)
		*crosspoint = m_crossPoint;
	return nCross;
}

//-----------------------------------------------------------------------------
// Name:
// Desc:
//-----------------------------------------------------------------------------
FLOAT CCamera::CalcD(D3DXVECTOR3& point, D3DXVECTOR3& normal)
{
	return -float(normal.x * point.x + normal.y * point.y + normal.z * point.z);
}

//-----------------------------------------------------------------------------
// Name:
// Desc:
//-----------------------------------------------------------------------------
BOOL CCamera::IsPointBehind(D3DXVECTOR3& point, D3DXVECTOR3& normal, FLOAT d)
{
	// ���ʂ�����
	float s;
	s = normal.x * point.x +
		normal.y * point.y +
		normal.z * point.z + d;
	return s <= 0;
}

//-----------------------------------------------------------------------------
// Name:
// Desc:
//-----------------------------------------------------------------------------
D3DXVECTOR3 CCamera::CalcCrossPoint(D3DXVECTOR3& point, D3DXVECTOR3& normal, D3DXVECTOR3& vector, FLOAT d)
{
	float num,
		  denom;
	
	num   = normal.x * point.x +
			normal.y * point.y +
			normal.z * point.z +
			d;
	denom = normal.x * vector.x +
			normal.y * vector.y +
			normal.z * vector.z;

	// ��_
	return point - vector * num / denom;
}

//-----------------------------------------------------------------------------
// File: Text.cpp
//
// Desc: ������̕\��
// 													programmed by S.G.Kohata
//-----------------------------------------------------------------------------
#include "CText.h"

LPDIRECT3DDEVICE9	CText::pd3dDevice;
CSprite*			CText::pText;

void CText::Create(LPDIRECT3DDEVICE9 pd3dDevice)
{
	CText::pd3dDevice = pd3dDevice;
	if (!pText) {
		pText = new CSprite(pd3dDevice, L"Textures/text.tga");
		pText->SetOffset(  0,  0);
		pText->SetSize  ( 48, 64);
		pText->SetRepeat( 10,  6);
	}
}

void CText::Release()
{
	delete pText;
	pText = NULL;
}

void CText::Render(int color, int x, int y, float scaleX, float scaleY ,char* fmt,...)
{
	char buf[512];

	va_list	ap;

	va_start(ap, fmt);
	vsprintf_s(buf, fmt, ap);
	va_end(ap);

	// �A���t�@�u�����h�w��
	pd3dDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	pd3dDevice->SetRenderState(D3DRS_SRCBLEND,  D3DBLEND_SRCALPHA);
	pd3dDevice->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
	pText->SetColor(color);
	for (UINT i = 0; i < strlen(buf); i++) {
		if (buf[i] >= 'A' && buf[i] <= 'Z')
			pText->SetPattern(buf[i] - 'A');
		else if (buf[i] == '0')
			pText->SetPattern(36);
		else if (buf[i] >= '1' && buf[i] <= '9')
			pText->SetPattern(27 + buf[i] - '1');
		else if (buf[i] == '_')
			pText->SetPattern(37);
		else if (buf[i] == '$')
			pText->SetPattern(38);
		else if (buf[i] == '\\')
			pText->SetPattern(39);
		else if (buf[i] == '%')
			pText->SetPattern(40);
		else if (buf[i] == ',')
			pText->SetPattern(41);
		else if (buf[i] == '.')
			pText->SetPattern(42);
		else if (buf[i] == '!')
			pText->SetPattern(43);
		else if (buf[i] == '?')
			pText->SetPattern(44);
		else if (buf[i] == '(')
			pText->SetPattern(45);
		else if (buf[i] == ')')
			pText->SetPattern(46);
		else if (buf[i] == '-')
			pText->SetPattern(47);
		else if (buf[i] == ':')
			pText->SetPattern(48);
		else if (buf[i] == '#')
			pText->SetPattern(49);
		else if (buf[i] == '<')
			pText->SetPattern(50);
		else if (buf[i] == '>')
			pText->SetPattern(51);
		else if (buf[i] == '[')
			pText->SetPattern(52);
		else if (buf[i] == ']')
			pText->SetPattern(53);
		else
			pText->SetPattern(26);
		pText->SetScale(scaleX / 48, scaleY / 64);
		pText->Render(pd3dDevice, x, y);
		x += scaleX;
	}
	pd3dDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
}

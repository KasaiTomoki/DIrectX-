//-----------------------------------------------------------------------------
// File: CResource.cpp
//
// Desc: Support code for loading DirectX .X files.
//		 supported copy diffuse to ambient
// 													programmed by S.G.Kohata
//-----------------------------------------------------------------------------
#include <stdio.h>
#include <d3d9.h>
#include <d3dx9.h>
#include "CResource.h"

//-----------------------------------------------------------------------------
// Name:
// Desc:
//-----------------------------------------------------------------------------
CResource* CResource::s_pTop = NULL;
CResource::CResource(WCHAR* pType)
{
	// �擪�ɘA�����Ă���
	m_pNext       = s_pTop;
	s_pTop        = this;
	wcscpy_s(m_sType, pType);
}

CResource::~CResource()
{
	// �����̈ʒu���������A�A������O��
	CResource* pWork = s_pTop;
	CResource* pBack = NULL;
	while (pWork) {
		if (pWork == this) {
			if (pBack)
				pBack->m_pNext = m_pNext;
			else
				s_pTop         = m_pNext;
			break;
		}
		pBack = pWork;
		pWork = pWork->m_pNext;
	}
}

HRESULT CResource::CheckFileExist(WCHAR* pFilename)
{
	HANDLE file = CreateFile(pFilename,
							 GENERIC_READ,
							 FILE_SHARE_READ,
							 NULL,
							 OPEN_EXISTING,
							 0,
							 NULL);
    if(INVALID_HANDLE_VALUE != file) {
        CloseHandle(file);
        return S_OK;
    }
	return D3DERR_NOTFOUND;
}

BOOL CResource::IsSameType(WCHAR* pType)
{
	if (wcscmp(m_sType, pType))
		return false;
	else
		return true;
}

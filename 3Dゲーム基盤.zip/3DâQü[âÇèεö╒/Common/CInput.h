#pragma once

#include <d3d9.h>
#include <d3dx9.h>
#include "DXUT.h"
#define DIRECTINPUT_VERSION 0x0800
#include <dinput.h>

class CInput {
	static LPDIRECTINPUT8		pDI;
	static LPDIRECTINPUTDEVICE8	pKeyboard;
	static LPDIRECTINPUTDEVICE8	pMouse;
	static BYTE					diksNow[256];	// ���݂̃L�[���
	static BYTE					diksOld[256];	// ���O�̃L�[���
	static DIMOUSESTATE2		dimsNow;		// ���݂̃}�E�X���
	static DIMOUSESTATE2		dimsOld;		// ���O�̃}�E�X���
	static POINT				dimpNow;		// ���݂̃}�E�X�ʒu
	static POINT				dimpOld;		// ���O�̃}�E�X�ʒu
	static POINT				windowOffset;	// �E�B���h�E�̈ʒu

private:
			CInput();
			~CInput();

public:
	static void  Create();
	static void  Destroy();
	static void	 UpdateInput();
	static BOOL	 IsKeyDown(int nKey);
	static BOOL	 IsKeyUp(int nKey);
	static BOOL	 IsKeyHold(int nKey);
	static BOOL  IsMouseDown(int nMouse);
	static BOOL  IsMouseUp(int nMouse);
	static BOOL  IsMouseHold(int nMouse);
	static POINT GetMousePos();	
	static DIMOUSESTATE2 GetMouseInfo() { return dimsNow; }
};

//-----------------------------------------------------------------------------
// File: CSprite.cpp
//
// Desc: �X�v���C�g�̊Ǘ�
// 													programmed by S.G.Kohata
//-----------------------------------------------------------------------------
#include <stdio.h>
#include <d3d9.h>
#include <d3dx9.h>
//#include "DXUtil.h"
#include "CSprite.h"
#include "math.h"

//-----------------------------------------------------------------------------
// Name:
// Desc:
//-----------------------------------------------------------------------------
CSprite::CSprite(LPDIRECT3DDEVICE9 pd3dDevice, WCHAR* pFilename, BOOL bTexel)
{
	m_pTexture	= new CTexture(pd3dDevice, pFilename);
	m_sOffset	= D3DXVECTOR2(0, 0);
	m_sSize		= D3DXVECTOR2(0, 0);
	m_sCenter	= D3DXVECTOR2(0, 0);
	m_sRepeat	= D3DXVECTOR2(1, 1);
	m_fScaleX	= 1;
	m_fScaleY	= 1;
	m_fRotate	= 0;
	m_nPattern	= 0;
	m_bTexel    = bTexel;

	// �Œ�l(Render�Ŗ���Œ�l������͖̂���)
	m_sVertex[0].rhw = 1;
	m_sVertex[1].rhw = 1;
	m_sVertex[2].rhw = 1;
	m_sVertex[3].rhw = 1;

	// �����l
	m_sVertex[0].color = D3DCOLOR_ARGB(255, 255, 255, 255);
	m_sVertex[1].color = D3DCOLOR_ARGB(255, 255, 255, 255);
	m_sVertex[2].color = D3DCOLOR_ARGB(255, 255, 255, 255);
	m_sVertex[3].color = D3DCOLOR_ARGB(255, 255, 255, 255);
}

CSprite::~CSprite()
{
	delete m_pTexture;
}

//-----------------------------------------------------------------------------
// Name: Set....
// Desc: �e��p�����[�^�ݒ�
//-----------------------------------------------------------------------------
void CSprite::SetOffset(D3DXVECTOR2* pOffset)
{
	m_sOffset = *pOffset;
}

void CSprite::SetSize(D3DXVECTOR2* pSize)
{
	m_sSize = *pSize;
}

void CSprite::SetCenter(D3DXVECTOR2* pCenter)
{
	m_sCenter = *pCenter;
}

void CSprite::SetRepeat(D3DXVECTOR2* pRepeat)
{
	m_sRepeat = *pRepeat;
}

void CSprite::SetOffset(int x, int y)
{
	m_sOffset.x = FLOAT(x);
	m_sOffset.y = FLOAT(y);
}

void CSprite::SetSize(int x, int y)
{
	m_sSize.x = FLOAT(x);
	m_sSize.y = FLOAT(y);
}

void CSprite::SetCenter(int x, int y)
{
	m_sCenter.x = FLOAT(x);
	m_sCenter.y = FLOAT(y);
}

void CSprite::SetRepeat(int x, int y)
{
	m_sRepeat.x = FLOAT(x);
	m_sRepeat.y = FLOAT(y);
}

void CSprite::SetScale(D3DXVECTOR2* pScale)
{
	m_fScaleX = pScale->x;
	m_fScaleY = pScale->y;
}

void CSprite::SetScale(FLOAT fScale)
{
	m_fScaleX = fScale;
	m_fScaleY = fScale;
}

void CSprite::SetScale(FLOAT fScaleX, FLOAT fScaleY)
{
	m_fScaleX = fScaleX;
	m_fScaleY = fScaleY;
}

void CSprite::SetRotate(FLOAT fRotate)
{
	m_fRotate = fRotate;
}

void CSprite::SetPattern(UINT nPattern)
{
	m_nPattern = nPattern;
}

void CSprite::SetColor(DWORD nColor)
{
	m_nColor			= nColor;
	m_sVertex[0].color	= m_nColor;
	m_sVertex[1].color	= m_nColor;
	m_sVertex[2].color	= m_nColor;
	m_sVertex[3].color	= m_nColor;
}

void CSprite::SetTexel(BOOL  bTexel)
{
	m_bTexel = bTexel;
}

//-----------------------------------------------------------------------------
// Name: Get....
// Desc: �e��p�����[�^�擾
//-----------------------------------------------------------------------------
D3DXVECTOR2* CSprite::GetOffset()
{
	return &m_sOffset;
}

D3DXVECTOR2* CSprite::GetSize()
{
	return &m_sSize;
}

D3DXVECTOR2* CSprite::GetCenter()
{
	return &m_sCenter;
}

D3DXVECTOR2* CSprite::GetRepeat()
{
	return &m_sRepeat;
}

FLOAT CSprite::GetScaleX()
{
	return m_fScaleX;
}

FLOAT CSprite::GetScaleY()
{
	return m_fScaleY;
}

FLOAT CSprite::GetRotate()
{
	return m_fRotate;
}

UINT CSprite::GetPattern()
{
	return m_nPattern;
}

DWORD CSprite::GetColor()
{
	return m_nColor;
}

BOOL CSprite::GetTexel()
{
	return m_bTexel;
}

//-----------------------------------------------------------------------------
// Name: Replace
// Desc: �e�N�X�`���̒u������
//-----------------------------------------------------------------------------
void CSprite::Replace(LPDIRECT3DDEVICE9 pd3dDevice, WCHAR* pFilename)
{
	m_pTexture->Replace(pd3dDevice, pFilename);
}

//-----------------------------------------------------------------------------
// Name: Render
// Desc: �\��
//-----------------------------------------------------------------------------
void CSprite::Render(LPDIRECT3DDEVICE9 pd3dDevice, D3DXVECTOR2* pLocation)
{
	Render(pd3dDevice, int(pLocation->x), int(pLocation->y));
}

void CSprite::Render(LPDIRECT3DDEVICE9 pd3dDevice, int nLocX, int nLocY)
{
	// �����̃��[�h�͕ύX����Ȃ��̂łP�x�̂ݐݒ�
	pd3dDevice->SetVertexShader(NULL);
	pd3dDevice->SetFVF(D3DFVF_XYZRHW|D3DFVF_DIFFUSE|D3DFVF_TEX1);

	// �|���S���ʒu
	FLOAT x = nLocX - m_sCenter.x;
	FLOAT y = nLocY - m_sCenter.y;
	FLOAT f = (m_bTexel?0.0f:0.5f);
	m_sVertex[0].point	= D3DXVECTOR3(x-f,				y-f,			0);
	m_sVertex[1].point	= D3DXVECTOR3(x-f+m_sSize.x,	y-f,			0);
	m_sVertex[2].point	= D3DXVECTOR3(x-f+m_sSize.x,	y-f+m_sSize.y,	0);
	m_sVertex[3].point	= D3DXVECTOR3(x-f,				y-f+m_sSize.y,	0);

	// ��]
	if (m_fRotate != 0 || m_fScaleX != 1 || m_fScaleY != 1) {
		for (int i = 0; i < 4; i++) {
			FLOAT x = (m_sVertex[i].point.x - nLocX) * m_fScaleX;
			FLOAT y = (m_sVertex[i].point.y - nLocY) * m_fScaleY;
			if (m_fRotate) {
				m_sVertex[i].point.x = x*cosf(m_fRotate) - y*sinf(m_fRotate) + nLocX;
				m_sVertex[i].point.y = x*sinf(m_fRotate) + y*cosf(m_fRotate) + nLocY;
			}
			else {
				m_sVertex[i].point.x = x + nLocX;
				m_sVertex[i].point.y = y + nLocY;
			}
		}
	}

	// �e�N�X�`��
	FLOAT w				= FLOAT(m_pTexture->GetWidth());
	FLOAT h				= FLOAT(m_pTexture->GetHeight());
	int   offX			= int(m_sOffset.x + (m_nPattern % int(m_sRepeat.x)) * m_sSize.x);
	int	  offY			= int(m_sOffset.y + (m_nPattern / int(m_sRepeat.x)) * m_sSize.y);
	m_sVertex[0].tex	= D3DXVECTOR2(offX/w+0.01f,				offY/h);
	m_sVertex[1].tex	= D3DXVECTOR2((offX + m_sSize.x)/w,	offY/h);
	m_sVertex[3].tex	= D3DXVECTOR2(offX/w+0.01f,				(offY + m_sSize.y)/h);
	m_sVertex[2].tex	= D3DXVECTOR2((offX + m_sSize.x)/w,	(offY + m_sSize.y)/h);

	pd3dDevice->SetTexture(0, *m_pTexture);
	pd3dDevice->SetRenderState(D3DRS_ZWRITEENABLE, FALSE);
	pd3dDevice->SetRenderState(D3DRS_CULLMODE,     D3DCULL_NONE);
	pd3dDevice->DrawPrimitiveUP(D3DPT_TRIANGLEFAN, 2, m_sVertex, sizeof(m_sVertex[0]));
	pd3dDevice->SetRenderState(D3DRS_ZWRITEENABLE, TRUE);
	pd3dDevice->SetRenderState(D3DRS_CULLMODE,     D3DCULL_CCW);
}

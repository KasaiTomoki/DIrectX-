#pragma once
#include "DXUT.h"

//�J�����Ǘ��N���X
class CameraMng
{
	static CameraMng* SingleTon;

	D3DXVECTOR3       vEye;//�J�����ʒu
	D3DXVECTOR3       vAt;//�J��������
	D3DXVECTOR3       vUp;

	                  CameraMng();
	                  ~CameraMng();
public:
	static void       Init();
	static void       Destroy();
	static CameraMng* Single() { return SingleTon; }

	D3DXVECTOR3       GetvEye() { return vEye; }
	D3DXVECTOR3       GetvAt() { return vAt; }
	D3DXVECTOR3       GetvUp() { return vUp; }

	void              SetvEye(D3DXVECTOR3 eye) { vEye = eye; }
	void              SetvAt(D3DXVECTOR3 at) { vAt = at; }
	void              SetvUp(D3DXVECTOR3 up) { vUp = up; }

	void              SetCamera(IDirect3DDevice9* device);
};


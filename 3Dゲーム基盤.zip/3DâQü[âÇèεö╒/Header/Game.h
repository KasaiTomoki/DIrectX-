#pragma once
#include "GameEnv.h"
#include "Object.h"
#include "ObjMng.h"
#include "Light.h"

class Game
{
	ObjMng*  pObjMng;
public:
	             Game();
	             ~Game();
     void        FrameMove();
     void        FrameRender();
};
//-----------------------------------------------------------------------------
// File: Game.h
//
// Desc: 
// 													programmed by S.G.Kohata
//-----------------------------------------------------------------------------
#pragma once
#define DIRECTINPUT_VERSION 0x0800
#include <dinput.h>
#include "DXUT.h"
#include "DXUTcamera.h"
#include "DXUTsettingsdlg.h"
#include "SDKmisc.h"
#include "SDKmesh.h"
#include "SDKsound.h"
#include "CAnimation.h"
#include "CText.h"
#include "CResource.h"
#include "CSprite.h"
#include "CInput.h"
#include "CMeshExt.h"
#include "CDebug.h"
#include "stack.h"
#include "SceneMng.h"
#include "CameraMng.h"
#include <vector>

using namespace std;

const int Display_X = 1024;
const int Display_Y = 768;

struct GameEnv_t 
{
	IDirect3DDevice9*	pd3dDevice;
	CSoundManager*		pSoundManager;
	double				fTime;			// ���s����
	float				fElapsedTime;	// �o�ߎ���
};

class Tool
{
public:
	static GameEnv_t tools;
};